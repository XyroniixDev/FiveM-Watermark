local watermarkSettings = {
    opacity = 0.5,
    size = { width = 100, height = 50 },
    position = { x = 0.85, y = 0.01 },
    image = 'media/watermark.png' -- Default image path
}

RegisterCommand('setwatermark', function(source, args, rawCommand)
    local option = args[1]
    local value = args[2]

    if option and value then
        if option == 'opacity' then
            watermarkSettings.opacity = tonumber(value) or watermarkSettings.opacity
        elseif option == 'size' then
            local width, height = value:match('(%d+),(%d+)')
            watermarkSettings.size.width = tonumber(width) or watermarkSettings.size.width
            watermarkSettings.size.height = tonumber(height) or watermarkSettings.size.height
        elseif option == 'position' then
            local x, y = value:match('(%d+),(%d+)')
            watermarkSettings.position.x = tonumber(x) or watermarkSettings.position.x
            watermarkSettings.position.y = tonumber(y) or watermarkSettings.position.y
        else
            TriggerEvent('chatMessage', '^1ERROR', {255, 255, 255}, 'Invalid option. Usage: /setwatermark [opacity/size/position] [value]')
        end
    else
        TriggerEvent('chatMessage', '^1ERROR', {255, 255, 255}, 'Invalid command. Usage: /setwatermark [opacity/size/position] [value]')
    end

    TriggerEvent('updateWatermarkSettings')
end, false)

RegisterNetEvent('updateWatermarkSettings')
AddEventHandler('updateWatermarkSettings', function()
    TriggerClientEvent('setWatermark', -1, watermarkSettings)
end)

AddEventHandler('playerSpawned', function()
    TriggerEvent('updateWatermarkSettings')
end)
